{ pkgs, ... }:

{
  home.packages = with pkgs; [
    brave
    librewolf
    vivaldi
    pywalfox-native
  ];
}
