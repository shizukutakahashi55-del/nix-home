{ pkgs, ... }:

{
  home.packages = with pkgs; [
    # Bars / launchers / session controls
    waybar
    rofi
    wlogout

    # Desktop utilities
    wlsunset
    libnotify
    networkmanagerapplet

    # Uncomment if Quickshell is not used.
    # swaync
  ];
}
