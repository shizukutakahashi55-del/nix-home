{ pkgs, ... }:

{
  home.packages = with pkgs; [
    gamemode
    lutris
    mangohud
    prismlauncher
    protonplus
    wine
    protontricks
    goverlay
    retroarch-full
  ];
}
